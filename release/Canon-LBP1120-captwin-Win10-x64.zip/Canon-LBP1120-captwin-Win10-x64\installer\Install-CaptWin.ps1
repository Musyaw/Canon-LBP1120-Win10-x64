﻿#Requires -RunAsAdministrator
<#
.SYNOPSIS
  One-shot installer: files, Ghostscript, WinUSB driver, Windows printer, autostart serve.
#>
param(
    [switch]$SkipGhostscript,
    [switch]$SkipWinUsb,
    [string]$InstallDir = "${env:ProgramFiles}\CanonLBP1120Capt"
)

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Payload = Split-Path -Parent $ScriptDir
if (-not (Test-Path (Join-Path $Payload "captwin.exe"))) {
    $devRelease = Join-Path (Split-Path $ScriptDir -Parent) "release\Canon-LBP1120-captwin-Win10-x64"
    if (Test-Path (Join-Path $devRelease "captwin.exe")) {
        $Payload = $devRelease
    }
}

$ErrorActionPreference = "Stop"
$SourceRoot = Split-Path -Parent $ScriptDir

Write-Host "`n=== Canon LBP1120 CAPT — установка ===" -ForegroundColor Cyan
Write-Host "Каталог: $InstallDir`n"

New-Item -ItemType Directory -Force -Path $InstallDir, "$InstallDir\data", "$InstallDir\tools" | Out-Null

$copyItems = @(
    "captwin.exe", "libwinpthread-1.dll", "README.ru.md", "LICENSES.txt",
    "install-winusb.ps1", "install-winusb.bat", "print-testpage.bat",
    "start-print-server.bat", "install-system-printer.ps1", "install-system-printer.bat"
)
foreach ($f in $copyItems) {
    $src = Join-Path $Payload $f
    if (Test-Path $src) { Copy-Item $src $InstallDir -Force }
}
if (Test-Path (Join-Path $Payload "data\example-1.pbm")) {
    Copy-Item (Join-Path $Payload "data\example-1.pbm") "$InstallDir\data\" -Force
}
if (Test-Path (Join-Path $Payload "tools\zadig.exe")) {
    Copy-Item (Join-Path $Payload "tools\zadig.exe") "$InstallDir\tools\" -Force
}

# Ghostscript
if (-not $SkipGhostscript) {
    $gs = Get-Command gswin64c.exe -ErrorAction SilentlyContinue
    if (-not $gs) {
        $gsPaths = @(
            "${env:ProgramFiles}\gs\*\bin\gswin64c.exe",
            "${env:ProgramFiles(x86)}\gs\*\bin\gswin64c.exe"
        )
        $found = $null
        foreach ($p in $gsPaths) {
            $hit = Get-Item $p -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($hit) { $found = $hit.FullName; break }
        }
        if (-not $found) {
            Write-Host "Установка Ghostscript (нужен для Ctrl+P)..." -ForegroundColor Yellow
            $winget = Get-Command winget -ErrorAction SilentlyContinue
            if ($winget) {
                winget install -e --id ArtifexSoftware.GhostScript --accept-package-agreements --accept-source-agreements 2>&1 | Out-Null
                if ($LASTEXITCODE -ne 0) {
                    winget install -e --id GPL.Ghostscript --accept-package-agreements --accept-source-agreements 2>&1 | Out-Null
                }
            } else {
                Write-Host "Установите Ghostscript вручную: https://ghostscript.com/releases/gsdnld.html" -ForegroundColor Yellow
            }
        }
    }
}

# WinUSB via INF (fallback: Zadig)
if (-not $SkipWinUsb) {
    $inf = Join-Path $ScriptDir "captwin_winusb.inf"
    if (Test-Path $inf) {
        Write-Host "Установка WinUSB-драйвера (INF)..." -ForegroundColor Yellow
        pnputil /add-driver $inf /install | Out-String | Write-Host
        Write-Host "Если принтер уже подключён: отключите USB на 5 сек и подключите снова." -ForegroundColor Yellow
        Write-Host "При ошибке подписи — запустите $InstallDir\tools\zadig.exe (WinUSB для 04A9:262B).`n"
    }
}

# Windows printer
$PrinterName = "Canon LBP1120 (CAPT)"
$PortName = "CaptWin_127.0.0.1_9100"
if (-not (Get-PrinterPort -Name $PortName -ErrorAction SilentlyContinue)) {
    Add-PrinterPort -Name $PortName -PrinterHostAddress "127.0.0.1" -PortNumber 9100
}
if (-not (Get-Printer -Name $PrinterName -ErrorAction SilentlyContinue)) {
    $psDriver = Get-PrinterDriver -Name "Microsoft PS Class Driver" -ErrorAction SilentlyContinue
    if ($psDriver) {
        Add-Printer -Name $PrinterName -DriverName "Microsoft PS Class Driver" -PortName $PortName
        Write-Host "Добавлен принтер Windows: $PrinterName" -ForegroundColor Green
    } else {
        Write-Host "Драйвер PS Class не найден — добавьте принтер вручную (IP 127.0.0.1:9100)." -ForegroundColor Yellow
    }
}

# Autostart print server at logon
$taskName = "CanonLBP1120CaptServe"
$exe = Join-Path $InstallDir "captwin.exe"
$action = New-ScheduledTaskAction -Execute $exe -Argument "serve --port 9100" -WorkingDirectory $InstallDir
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Settings $settings -Force | Out-Null
Start-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue

# Shortcuts
$shell = New-Object -ComObject WScript.Shell
$desktop = [Environment]::GetFolderPath("Desktop")
$lnk = $shell.CreateShortcut((Join-Path $desktop "Canon LBP1120 — тестовая печать.lnk"))
$lnk.TargetPath = Join-Path $InstallDir "print-testpage.bat"
$lnk.WorkingDirectory = $InstallDir
$lnk.Save()

$lnk2 = $shell.CreateShortcut((Join-Path $desktop "Canon LBP1120 — справка.lnk"))
$lnk2.TargetPath = Join-Path $InstallDir "README.ru.md"
$lnk2.Save()

Write-Host @"

=== Готово ===
  Программа: $InstallDir
  Печать с сайта: Ctrl+P -> "$PrinterName"
  Сервер печати запускается при входе в Windows.

  Тест: ярлык на рабочем столе или:
    "$exe" testpage

"@ -ForegroundColor Green
