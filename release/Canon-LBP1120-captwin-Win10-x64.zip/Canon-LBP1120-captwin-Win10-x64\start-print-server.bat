@echo off
cd /d "%~dp0"
echo CAPT print server (keep this window open while printing from browser)
echo Requires Ghostscript (gswin64c.exe) in PATH or Program Files\gs
captwin.exe serve --port 9100
pause
